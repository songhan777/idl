# IDL生产技术规范与参考工程

以 OpenAPI 3.1.0 约定 HTTP JSON 前后端接口，提供生产开发规范、完整 Project CRUD 契约、数据正反例、TypeScript 调用样例与持续集成配置。

## 阅读文档

- [完整技术规范](docs/IDL-生产技术规范.md)：24 节，覆盖设计、实现、安全、可靠性、版本治理、上线验收和排障。
- [浏览器阅读版](docs/IDL-生产技术规范.html)：离线可读，含章节目录和完整契约快照。
- [OpenAPI 契约](contracts/openapi.yaml)：五种 Project 操作及全部请求、响应和错误定义。
- [契约工具说明](docs/CONTRACT_PACKAGE.md)：校验范围、依赖与 CI 使用方法。
- [TypeScript 客户端说明](examples/typescript/README.md)：调用方式、错误处理和测试边界。
- [本次验证记录](docs/VALIDATION.md)：实际运行结果与目标环境待验收内容。

## 技术基线

| 工具 | 固定版本 |
| --- | --- |
| OpenAPI | 3.1.0 |
| Python | 本次与 CI 为 3.12.14 |
| Node.js | 本次与 CI 为 24.19.0 |
| pnpm | 11.19.0 |
| openapi-typescript | 7.13.0 |
| openapi-fetch | 0.17.0 |
| TypeScript | 5.9.3 |
| Redocly CLI | 2.53.0 |

这些版本是本工程固定的验证基线。Node 依赖解析保存在 `pnpm-lock.yaml`，Python 依赖保存在 `requirements-contract.lock`。`pnpm-workspace.yaml` 固定包管理器行为。若尚未安装 pnpm，可以在已有 Node/npm 环境执行 `npm install --global pnpm@11.19.0`。

## Windows快速开始

在仓库根目录的 PowerShell 执行：

```powershell
py -3.12 -m venv .venv
.venv/Scripts/python.exe -m pip install -r requirements-contract.lock
.venv/Scripts/python.exe scripts/verify_contract.py
.venv/Scripts/python.exe -m unittest discover -s tests -v
pnpm install --frozen-lockfile
pnpm validate
.venv/Scripts/python.exe scripts/build_docs.py
```

## Linux与macOS快速开始

```bash
python3.12 -m venv .venv
.venv/bin/python -m pip install -r requirements-contract.lock
.venv/bin/python scripts/verify_contract.py
.venv/bin/python -m unittest discover -s tests -v
pnpm install --frozen-lockfile
pnpm validate
.venv/bin/python scripts/build_docs.py
```

契约修改后执行 `pnpm generate` 更新类型，再执行 `pnpm validate`。不要编辑生成的 `examples/typescript/schema.d.ts`。`scripts/build_docs.py` 只使用 Python 标准库，按 Markdown 与 YAML 源文件重新生成阅读版。

## 生产接入

文档与契约可以纳入团队仓库使用；参考工程包含静态校验和客户端样例。业务服务需要实现实际认证、对象授权、数据库事务、幂等存储、条件更新和网关策略。将 `example.com` 服务及认证地址替换为真实受控配置，按技术规范中的验收矩阵验证后发布。

GitHub Actions 工作流已提供静态检查与客户端检查。生产契约基线、真实提供方测试、性能容量、密钥管理、灰度和回滚流程需要连接团队实际环境，详见技术规范第 19 至 23 节。发布历史为空时，登记首次发布验收后再建立生产契约基线。

